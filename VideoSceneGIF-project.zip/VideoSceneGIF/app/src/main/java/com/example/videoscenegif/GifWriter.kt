package com.example.videoscenegif

import android.graphics.Bitmap
import java.io.OutputStream

/** Minimal GIF89a writer with 3-3-2 RGB palette and lossless LZW indices. */
class GifWriter(private val output: OutputStream, private val width: Int, private val height: Int) {
    private fun word(v: Int) { output.write(v and 255); output.write((v shr 8) and 255) }
    private fun ascii(s: String) { output.write(s.toByteArray(Charsets.US_ASCII)) }
    init {
        ascii("GIF89a"); word(width); word(height); output.write(0xF7); output.write(0); output.write(0)
        for (i in 0..255) {
            output.write(((i shr 5) and 7) * 255 / 7)
            output.write(((i shr 2) and 7) * 255 / 7)
            output.write((i and 3) * 255 / 3)
        }
        output.write(byteArrayOf(0x21, 0xFF.toByte(), 11))
        ascii("NETSCAPE2.0")
        output.write(byteArrayOf(3, 1, 0, 0, 0))
    }
    fun frame(bitmap: Bitmap, delayCentiseconds: Int = 8) {
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val indices = ByteArray(pixels.size)
        for (i in pixels.indices) {
            val c = pixels[i]
            indices[i] = (((c shr 16 and 255) shr 5 shl 5) or ((c shr 8 and 255) shr 5 shl 2) or ((c and 255) shr 6)).toByte()
        }
        output.write(byteArrayOf(0x21, 0xF9.toByte(), 4, 0, (delayCentiseconds and 255).toByte(), (delayCentiseconds shr 8).toByte(), 0, 0))
        output.write(0x2C); word(0); word(0); word(width); word(height); output.write(0)
        output.write(8)
        val encoded = lzw(indices)
        var pos = 0
        while (pos < encoded.size) { val n = minOf(255, encoded.size - pos); output.write(n); output.write(encoded, pos, n); pos += n }
        output.write(0)
    }
    private fun lzw(input: ByteArray): ByteArray {
        val clear = 256; val end = 257
        val bytes = java.io.ByteArrayOutputStream()
        var bits = 0L; var count = 0
        var size = 9; var next = 258
        val dictionary = HashMap<Long, Int>()
        fun emit(code: Int) {
            bits = bits or (code.toLong() shl count); count += size
            while (count >= 8) { bytes.write((bits and 255).toInt()); bits = bits ushr 8; count -= 8 }
        }
        emit(clear)
        if (input.isNotEmpty()) {
            var prefix = input[0].toInt() and 255
            for (i in 1 until input.size) {
                val v = input[i].toInt() and 255
                val key = (prefix.toLong() shl 8) or v.toLong()
                val found = dictionary[key]
                if (found != null) { prefix = found }
                else {
                    emit(prefix)
                    if (next < 4096) {
                        dictionary[key] = next++
                        if (next == (1 shl size) + 1 && size < 12) size++
                    } else {
                        emit(clear); dictionary.clear(); size = 9; next = 258
                    }
                    prefix = v
                }
            }
            emit(prefix)
        }
        emit(end)
        if (count > 0) bytes.write((bits and 255).toInt())
        return bytes.toByteArray()
    }
    fun finish() { output.write(0x3B); output.flush() }
}
