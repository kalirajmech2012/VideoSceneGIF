package com.example.videoscenegif

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import android.view.Gravity
import android.widget.*
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var start: Button
    private var video: Uri? = null
    private var outputFolder: Uri? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 48, 36, 24) }
        root.addView(TextView(this).apply { text = "Video Scene GIF"; textSize = 27f; setTextColor(Color.BLACK) })
        root.addView(TextView(this).apply { text = "480px • 12 FPS • scene-aware splitting • maximum 10s per GIF"; textSize = 15f })
        fun button(title: String, action: () -> Unit) = Button(this).also { it.text = title; it.setOnClickListener { action() }; root.addView(it) }
        button("1. Choose video") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1) }
        button("2. Choose output folder") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2) }
        start = button("3. Create GIF files") { convert() }
        status = TextView(this).apply { text = "Select video and destination folder."; textSize = 16f; gravity = Gravity.START; setPadding(0, 20, 0, 0) }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }
    @Deprecated("Legacy activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == 1) video = uri else if (requestCode == 2) outputFolder = uri
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or if (requestCode == 2) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0) } catch (_: Exception) {}
        status.text = "Video: ${if (video != null) "selected" else "missing"}\nOutput folder: ${if (outputFolder != null) "selected" else "missing"}"
    }
    private fun update(message: String) = runOnUiThread { status.text = message }
    private fun convert() {
        val source = video ?: return update("Choose a video first")
        val folder = outputFolder ?: return update("Choose an output folder first")
        start.isEnabled = false
        thread {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, source)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: error("Cannot read duration")
                val durationUs = durationMs * 1000L
                val stepUs = 1_000_000L
                val boundaries = mutableListOf(0L)
                var previous: IntArray? = null
                var t = 0L
                update("Detecting scene changes...")
                while (t < durationUs) {
                    val frame = retriever.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (frame != null) {
                        val small = Bitmap.createScaledBitmap(frame, 16, 16, true)
                        val pixels = IntArray(256); small.getPixels(pixels, 0, 16, 0, 0, 16, 16)
                        val prior = previous
                        if (prior != null) {
                            var score = 0L
                            for (i in pixels.indices) {
                                score += abs(Color.red(pixels[i]) - Color.red(prior[i]))
                                score += abs(Color.green(pixels[i]) - Color.green(prior[i]))
                                score += abs(Color.blue(pixels[i]) - Color.blue(prior[i]))
                            }
                            if (score / (256.0 * 3.0 * 255.0) > 0.30 && t - boundaries.last() >= 2_000_000L) boundaries.add(t)
                        }
                        previous = pixels
                        small.recycle(); frame.recycle()
                    }
                    t += stepUs
                }
                boundaries.add(durationUs)
                val clips = mutableListOf<Pair<Long, Long>>()
                for (i in 0 until boundaries.size - 1) {
                    var s = boundaries[i]; val end = boundaries[i + 1]
                    while (s < end) { val e = minOf(s + 10_000_000L, end); if (e - s >= 500_000L) clips.add(s to e); s = e }
                }
                val directory = DocumentsContract.buildDocumentUriUsingTree(folder, DocumentsContract.getTreeDocumentId(folder))
                var success = 0
                for ((index, clip) in clips.withIndex()) {
                    update("Creating GIF ${index + 1} / ${clips.size}...")
                    val filename = "scene_%04d.gif".format(index + 1)
                    val dest = DocumentsContract.createDocument(contentResolver, directory, "image/gif", filename) ?: continue
                    try {
                        contentResolver.openOutputStream(dest)?.use { stream ->
                            val fps = 12; val frameStep = 1_000_000L / fps
                            var time = clip.first
                            var writer: GifWriter? = null
                            while (time < clip.second) {
                                val frame = retriever.getFrameAtTime(time, MediaMetadataRetriever.OPTION_CLOSEST)
                                if (frame != null) {
                                    val w = minOf(480, frame.width); val h = max(1, (frame.height.toDouble() * w / frame.width).toInt())
                                    val resized = Bitmap.createScaledBitmap(frame, w, h, true)
                                    if (writer == null) writer = GifWriter(stream, w, h)
                                    writer.frame(resized, 8)
                                    resized.recycle(); if (resized !== frame) frame.recycle()
                                }
                                time += frameStep
                            }
                            writer?.finish()
                        }
                        success++
                    } catch (e: Exception) { contentResolver.delete(dest, null, null); throw e }
                }
                update("Finished: $success GIF files saved in your selected folder.")
            } catch (e: Exception) { update("Conversion failed: ${e.message}") }
            finally { retriever.release(); runOnUiThread { start.isEnabled = true } }
        }
    }
}
