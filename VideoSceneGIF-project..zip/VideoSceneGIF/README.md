# Video Scene GIF

Android offline video-to-GIF converter. Select a video, select a destination folder, and create 480-pixel-wide (maximum), 12-FPS looping GIFs. Detects large visual scene changes from one-second samples and limits each segment to 10 seconds. No network permission.

## Build using GitHub Actions
Create a new repository, upload the contents of this folder (including `.github/workflows/build.yml`), and open **Actions → Build Android APK → Run workflow**. After a successful run, download `VideoSceneGIF-debug-apk` from the workflow's **Artifacts** section, unzip it and install `app-debug.apk`.

## Limitations
Scene detection is visual-difference based, not AI content recognition. Scene changes sampled at 1-second intervals may be missed; camera motion may cause false splits. Conversion is CPU-intensive and a 30-minute video can create hundreds of large GIFs, taking significant time and storage. GIF has 256 colors; output uses a fixed RGB332 palette. The app does not request broad storage permissions. It is an initial implementation, not yet device-tested.
