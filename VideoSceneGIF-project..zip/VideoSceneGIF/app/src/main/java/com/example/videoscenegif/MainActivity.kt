package com.example.videoscenegif

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import android.view.Gravity
import android.widget.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var stop: Button
    private var video: Uri? = null
    private var outputFolder: Uri? = null
    private val cancelled = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 24)
        }
        root.addView(TextView(this).apply {
            text = "VideoSceneGIF V2"
            textSize = 26f
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "Fixed 6-second clips | 320px | 10 FPS | Offline"
            textSize = 15f
        })
        fun button(title: String, action: () -> Unit) = Button(this).also {
            it.text = title
            it.setOnClickListener { action() }
            root.addView(it)
        }
        button("1. Choose video") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }, 1)
        }
        button("2. Choose output folder") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2)
        }
        start = button("3. Create 6-second GIFs") { convert() }
        stop = button("Stop after current GIF") { cancelled.set(true) }
        stop.isEnabled = false
        status = TextView(this).apply {
            text = "Choose a video and destination folder."
            textSize = 16f
            gravity = Gravity.START
            setPadding(0, 20, 0, 0)
        }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Legacy activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == 1) video = uri else if (requestCode == 2) outputFolder = uri
        try {
            val flags = if (requestCode == 2)
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            else Intent.FLAG_GRANT_READ_URI_PERMISSION
            contentResolver.takePersistableUriPermission(uri, flags)
        } catch (_: Exception) { }
        update("Video: ${if (video != null) "selected" else "missing"}\nFolder: ${if (outputFolder != null) "selected" else "missing"}")
    }

    private fun update(message: String) = runOnUiThread { status.text = message }

    private fun convert() {
        val source = video ?: return update("Choose a video first")
        val folder = outputFolder ?: return update("Choose an output folder first")
        cancelled.set(false)
        start.isEnabled = false
        stop.isEnabled = true
        thread {
            val retriever = MediaMetadataRetriever()
            var completed = 0
            try {
                retriever.setDataSource(this, source)
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: error("Video duration unavailable")
                val clipMs = 6000L
                val total = ((durationMs + clipMs - 1) / clipMs).toInt()
                val directory = DocumentsContract.buildDocumentUriUsingTree(
                    folder, DocumentsContract.getTreeDocumentId(folder))
                for (index in 0 until total) {
                    if (cancelled.get()) break
                    update("Creating GIF ${index + 1} / $total | Saved $completed")
                    val beginMs = index * clipMs
                    val endMs = minOf(beginMs + clipMs, durationMs)
                    val dest = DocumentsContract.createDocument(
                        contentResolver, directory, "image/gif", "clip_%04d.gif".format(index + 1))
                        ?: error("Cannot create output file")
                    try {
                        var written = 0
                        contentResolver.openOutputStream(dest, "w")?.use { output ->
                            var writer: GifWriter? = null
                            var ms = beginMs
                            while (ms < endMs) {
                                // Fast sync-frame sampling: faster, but exact 10 FPS unique frames
                                // cannot be guaranteed for videos with sparse keyframes.
                                val frame = retriever.getFrameAtTime(ms * 1000L,
                                    MediaMetadataRetriever.OPTION_CLOSEST)
                                if (frame != null) {
                                    val w = minOf(320, frame.width)
                                    val h = max(1, frame.height * w / frame.width)
                                    val resized = Bitmap.createScaledBitmap(frame, w, h, true)
                                    if (writer == null) writer = GifWriter(output, w, h)
                                    writer.frame(resized, 10)
                                    written++
                                    if (resized !== frame) resized.recycle()
                                    frame.recycle()
                                }
                                ms += 100L
                            }
                            if (written == 0) error("No frames decoded for clip ${index + 1}")
                            writer?.finish()
                        } ?: error("Cannot open output stream")
                        completed++
                    } catch (e: Exception) {
                        contentResolver.delete(dest, null, null)
                        throw e
                    }
                }
                update("${if (cancelled.get()) "Stopped" else "Finished"}: $completed GIF files saved.")
            } catch (e: Exception) {
                update("Failed after $completed GIFs: ${e.message}")
            } finally {
                retriever.release()
                runOnUiThread { start.isEnabled = true; stop.isEnabled = false }
            }
        }
    }
}
