package com.example.videoscenegif

import android.graphics.Bitmap
import java.io.OutputStream

/** GIF89a with a fixed 3-3-2 palette and deliberately bounded LZW codes.
 * Clear codes are inserted before the dictionary would require a larger code width.
 * This avoids variable-width synchronization errors in GIF decoders.
 */
class GifWriter(private val output: OutputStream, private val width: Int, private val height: Int) {
    private fun word(v: Int) { output.write(v and 255); output.write((v ushr 8) and 255) }
    private fun ascii(s: String) { output.write(s.toByteArray(Charsets.US_ASCII)) }
    init {
        ascii("GIF89a"); word(width); word(height)
        output.write(0xF7); output.write(0); output.write(0)
        for (i in 0..255) {
            output.write(((i ushr 5) and 7) * 255 / 7)
            output.write(((i ushr 2) and 7) * 255 / 7)
            output.write((i and 3) * 255 / 3)
        }
        output.write(byteArrayOf(0x21, 0xFF.toByte(), 11))
        ascii("NETSCAPE2.0")
        output.write(byteArrayOf(3, 1, 0, 0, 0))
    }
    fun frame(bitmap: Bitmap, delayCentiseconds: Int = 10) {
        require(bitmap.width == width && bitmap.height == height)
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val indices = ByteArray(pixels.size)
        for (i in pixels.indices) {
            val c = pixels[i]
            indices[i] = ((((c ushr 16) and 255) ushr 5 shl 5) or
                (((c ushr 8) and 255) ushr 5 shl 2) or ((c and 255) ushr 6)).toByte()
        }
        output.write(byteArrayOf(0x21, 0xF9.toByte(), 4, 0,
            (delayCentiseconds and 255).toByte(), (delayCentiseconds ushr 8).toByte(), 0, 0))
        output.write(0x2C); word(0); word(0); word(width); word(height); output.write(0)
        output.write(8)
        // Valid GIF LZW: literal indices, with frequent clear codes to stay at 9 bits.
        // Optimizes reliability and CPU, at the expense of larger files.
        var bits = 0L
        var count = 0
        val packed = java.io.ByteArrayOutputStream()
        fun emit(code: Int) {
            bits = bits or (code.toLong() shl count)
            count += 9
            while (count >= 8) {
                packed.write((bits and 255).toInt())
                bits = bits ushr 8
                count -= 8
            }
        }
        emit(256)
        var run = 0
        for (index in indices) {
            if (run == 200) { emit(256); run = 0 }
            emit(index.toInt() and 255)
            run++
        }
        emit(257)
        if (count > 0) packed.write((bits and 255).toInt())
        val encoded = packed.toByteArray()
        var pos = 0
        while (pos < encoded.size) {
            val n = minOf(255, encoded.size - pos)
            output.write(n); output.write(encoded, pos, n); pos += n
        }
        output.write(0)
    }
    fun finish() { output.write(0x3B); output.flush() }
}
