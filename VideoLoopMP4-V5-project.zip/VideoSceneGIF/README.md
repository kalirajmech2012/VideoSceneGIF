# VideoLoop MP4 V5 — original duration only

Select input folder with `.ts` clips and a separate output folder. Converts each
clip to MP4 without repeating video or audio, preserving video bitstream and
original approximate duration (e.g. 4 seconds). No GIF conversion.

**IMPORTANT:** Prototype is not built or device-tested. Requires source video
H.264/AVC and **existing AAC audio**. Non-AAC TS audio is rejected, not
transcoded. Android MediaExtractor support for TS varies by device. Original
video duration may differ slightly due to timestamp normalization. WhatsApp
autoplay looping cannot be controlled by the app.
