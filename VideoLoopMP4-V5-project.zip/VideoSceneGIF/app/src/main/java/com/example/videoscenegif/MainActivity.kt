package com.example.videoscenegif

import android.app.Activity
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private var input: Uri? = null
    private var output: Uri? = null
    private lateinit var status: TextView
    private lateinit var start: Button
    private lateinit var stop: Button
    @Volatile private var cancelled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 40, 28, 24) }
        layout.addView(TextView(this).apply { text = "VideoLoop MP4\n4-second TS to MP4 Batch Converter"; textSize = 23f })
        val inputButton = Button(this).apply { text = "1. Select TS video folder" }
        val outputButton = Button(this).apply { text = "2. Select MP4 output folder" }
        layout.addView(inputButton)
        layout.addView(outputButton)
        start = Button(this).apply { text = "3. Convert all to MP4"; isEnabled = false }
        stop = Button(this).apply { text = "Stop"; isEnabled = false }
        status = TextView(this).apply { text = "Select both folders. No internet or storage permission required."; textSize = 15f }
        listOf(start, stop, status).forEach(layout::addView)
        setContentView(ScrollView(this).apply { addView(layout) })
        inputButton.setOnClickListener { pick(101) }
        outputButton.setOnClickListener { pick(102) }
        start.setOnClickListener { convertAll() }
        stop.setOnClickListener { cancelled = true; status.text = "Stopping..." }
    }

    private fun pick(code: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, code)
    }

    @Deprecated("Activity result for Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri,
                if (requestCode == 101) Intent.FLAG_GRANT_READ_URI_PERMISSION
                else Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: SecurityException) {}
        if (requestCode == 101) input = uri else output = uri
        status.text = "Input selected: ${input != null} | Output selected: ${output != null}"
        start.isEnabled = input != null && output != null
    }

    private fun update(s: String) = runOnUiThread { status.text = s }

    private fun convertAll() {
        val inUri = input ?: return
        val outUri = output ?: return
        if (inUri == outUri) { update("Please select different input/output folders."); return }
        cancelled = false
        start.isEnabled = false
        stop.isEnabled = true
        worker.execute {
            var success = 0
            var failed = 0
            try {
                val files = DocumentFile.fromTreeUri(this, inUri)?.listFiles()
                    ?.filter { it.isFile && (it.name ?: "").lowercase().matches(Regex(".*\\.(ts|mp4|m4v)")) }
                    ?.sortedBy { it.name } ?: emptyList()
                for ((i, file) in files.withIndex()) {
                    if (cancelled) break
                    update("Converting ${i+1}/${files.size}: ${file.name}\nSuccess: $success | Failed: $failed")
                    try { convertOne(file.uri, outUri, file.name ?: "video_$i"); success++ }
                    catch (e: Exception) { failed++; update("Failed ${file.name}: ${e.message}") }
                }
                update("Done. MP4: $success | Failed: $failed${if (cancelled) " | Stopped" else ""}")
            } catch (e: Exception) { update("Error: ${e.message}") }
            finally { runOnUiThread { start.isEnabled = true; stop.isEnabled = false } }
        }
    }

    private fun convertOne(source: Uri, outputFolder: Uri, name: String) {
        val extractor = MediaExtractor()
        val fd = contentResolver.openFileDescriptor(source, "r") ?: error("Cannot open source")
        var temp: File? = null
        var created: DocumentFile? = null
        try {
            extractor.setDataSource(fd.fileDescriptor)
            val videoTrack = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
            } ?: error("No video stream found")
            val audioTrack = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: error("No audio stream found: cannot create video with sound")
            val videoFormat = extractor.getTrackFormat(videoTrack)
            val audioFormat = extractor.getTrackFormat(audioTrack)
            require(videoFormat.getString(MediaFormat.KEY_MIME) == "video/avc") {
                "This build requires H.264/AVC video"
            }
            require(audioFormat.getString(MediaFormat.KEY_MIME) == "audio/mp4a-latm") {
                "Audio is not AAC. This build cannot transcode ${audioFormat.getString(MediaFormat.KEY_MIME)}; needs AAC encoder."
            }
            val base = name.substringBeforeLast('.').replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val outName = "${base}.mp4"
            temp = File.createTempFile("videoloop_", ".mp4", cacheDir)
            val muxer = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val vOut = muxer.addTrack(videoFormat)
                val aOut = muxer.addTrack(audioFormat)
                muxer.start()
                // Read each source track separately, preserving stream samples and time order.
                // MediaMuxer accepts interleaved writes across tracks.
                val tracks = listOf(videoTrack to vOut, audioTrack to aOut)
                val durations = mutableMapOf<Int, Long>()
                for ((sourceTrack, targetTrack) in tracks) {
                    extractor.selectTrack(sourceTrack)
                    extractor.seekTo(0, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                    val samples = mutableListOf<Triple<Long, Int, ByteArray>>()
                    val maxSize = 8 * 1024 * 1024
                    val buffer = ByteBuffer.allocate(maxSize)
                    while (!cancelled) {
                        val index = extractor.sampleTrackIndex
                        if (index < 0) break
                        if (index != sourceTrack) {
                            if (!extractor.advance()) break
                            continue
                        }
                        buffer.clear()
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) break
                        val bytes = ByteArray(size)
                        buffer.position(0)
                        buffer.get(bytes)
                        samples.add(Triple(extractor.sampleTime, extractor.sampleFlags, bytes))
                        if (!extractor.advance()) break
                    }
                    extractor.unselectTrack(sourceTrack)
                    require(samples.isNotEmpty()) { "No samples in stream" }
                    val sorted = samples.sortedBy { it.first }
                    val origin = sorted.first().first
                    val step = if (sorted.size > 1)
                        (sorted.last().first - sorted[sorted.size - 2].first).coerceAtLeast(1L)
                        else 40000L
                    val span = (sorted.last().first - origin + step).coerceAtLeast(1L)
                    durations[sourceTrack] = span
                    val info = MediaCodec.BufferInfo()
                    for ((time, flags, bytes) in sorted) {
                        if (cancelled) break
                        val sample = ByteBuffer.wrap(bytes)
                        info.set(0, bytes.size, time - origin, flags)
                        muxer.writeSampleData(targetTrack, sample, info)
                    }
                }
                muxer.stop()
            } finally { muxer.release() }
            if (cancelled) return
            val dir = DocumentFile.fromTreeUri(this, outputFolder) ?: error("Output folder inaccessible")
            dir.findFile(outName)?.delete()
            created = dir.createFile("video/mp4", outName) ?: error("Cannot create output")
            contentResolver.openOutputStream(created.uri, "w")?.use { stream ->
                temp.inputStream().use { it.copyTo(stream) }
            } ?: error("Cannot write output")
            require(created.length() > 100) { "Output file empty" }
        } catch (e: Exception) {
            created?.delete()
            throw e
        } finally {
            extractor.release()
            fd.close()
            temp?.delete()
        }
    }
}
