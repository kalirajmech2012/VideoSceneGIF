plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.videoscenegif"; compileSdk = 35
 defaultConfig { applicationId = "com.example.videoscenegif"; minSdk = 26; targetSdk = 35; versionCode = 5; versionName = "5.0" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}

dependencies { implementation("androidx.documentfile:documentfile:1.0.1") }
